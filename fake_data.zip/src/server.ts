import express from 'express';
import makeData from './fake_data';

class Server {
  private app: express.Application;

  constructor() {
    this.app = express();
    this.route();
  }

  private route() {
    this.app.get('/data', (req: express.Request, res) => {
      res.json({ result: makeData(Number(req.query.size)) });
    });
  }

  public getInstance() {
    return this.app;
  }
}

export default Server;
